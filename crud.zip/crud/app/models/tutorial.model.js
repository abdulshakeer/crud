module.exports = (sequelize, Sequelize) => {
  const Tutorial = sequelize.define("tutorial", {
    title: {
      type: Sequelize.STRING,
      validate:{
        notEmpty: true, // don't allow empty strings

      }

    },
    description: {
      type: Sequelize.STRING,
      validate:{
        len: [2, 10], // only allow values with length between 2 and 10

      }
    },
    published: {
      type: Sequelize.BOOLEAN
    },
   
  });

  return Tutorial;
};
